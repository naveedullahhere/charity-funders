<?php echo $__env->make('management/layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('management/layouts/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('management.theme.includes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="content">
    <?php echo $__env->yieldContent('content'); ?>
</section>
<?php echo $__env->make('management/layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/layouts/master.blade.php ENDPATH**/ ?>