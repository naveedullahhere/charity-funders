<?php echo Form::model($user, ['method' => 'PATCH', 'route' => ['users.update', $user->id], 'id' => 'ajaxSubmit']); ?>

<input type="hidden" id="url" value="<?php echo e(route('users.index')); ?>" />

<div class="row">
<div class="col-md-12 -auto">
                                                <div class="avatar-upload">
                                                    <div class="avatar-edit">
                                                        <input type='file' id="imageUpload" name="profile_image"
                                                            accept=".png, .jpg, .jpeg" />
                                                        <label for="imageUpload">
                                                           <i class="ft-camera"></i>
                                                        </label>
                                                    </div>
                                                    <div class="avatar-preview">
                                                        <div id="imagePreview"
                                                            style="background-image: url('<?php echo e(image_path(auth()->user()->profile_image)); ?>');">
                                                        </div>
                                                    </div>
                                                </div>
                                                <p class="text-center mt-2"><?php echo e('@'.auth()->user()->username); ?></p>
                                            </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Name:</label>
            <?php echo Form::text('name', null, ['placeholder' => 'Name', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Email:</label>
            <?php echo Form::text('email', null, ['placeholder' => 'Email', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Password:</label>
            <?php echo Form::password('password', ['placeholder' => 'Password', 'class' => 'form-control']); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Confirm Password:</label>
            <?php echo Form::password('confirm-password', ['placeholder' => 'Confirm Password', 'class' => 'form-control']); ?>

        </div>
    </div>
    
    
    
    
    
    
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Roles:</label>
            <br>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleId => $roleName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                    <?php echo Form::checkbox('roles[]', $roleId, in_array($roleId, $userRole)); ?>

                    <span><?php echo e($roleName); ?></span>
                </label>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<div class="row bottom-button-bar">
    <div class="col-12">
        <a type="button" class="btn btn-danger modal-sidebar-close position-relative top-1 closebutton">Close</a>
        <button type="submit" class="btn btn-primary submitbutton">Save</button>
    </div>
</div>
<?php echo Form::close(); ?>

<?php /**PATH C:\xampp82\htdocs\charity-funders\resources\views/management/acl/users/edit.blade.php ENDPATH**/ ?>