<table class="table">
    <thead>
        <tr>
            <!-- <th class="col-lg-3">S no.</th> -->
            <th class="col-lg-3">Name</th>
            <th class="col-lg-2">Name</th>
            <th class="col-lg-5">Action</th>
            <th class="col-lg-3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($AthleteProfiles) != 0): ?>
        <?php $__currentLoopData = $AthleteProfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $AthleteProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td>
                <a href="javascript:;" onclick="openModal('<?php echo e(route('athletes.edit',$AthleteProfile->id)); ?>','View Athletes',true)">
                    <?php echo e($AthleteProfile->name); ?> <br>
                    <?php echo e($AthleteProfile->email); ?> <br>
                </a>
            </td>
            <td>
                <?php if($AthleteProfile->user): ?>
                <label for="" class="badge btn-success">
                    Registered
                </label>
                <?php else: ?>
                <label for="" class="badge btn-danger">
                    Not Registered
                </label>
                <?php endif; ?>
            </td>
            <td>
                <input type="text" readonly class="form-control" value="<?php echo e(url('athlete-profile',$AthleteProfile->unique_string)); ?>">
            </td>
            <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                <button class="btn btn-primary" onclick="openModal('<?php echo e(route('athletes.edit',$AthleteProfile->id)); ?>','Edit Athletes')"><span class="material-symbols-outlined">edit</span></button>

                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>

                <button class="btn btn-danger " <?php echo e($AthleteProfile->user != null ? 'disabled' : ''); ?> onclick="deletemodal('<?php echo e(route('athletes.destroy',$AthleteProfile->id)); ?>')"><span class="material-symbols-outlined">delete</span></button>

                <?php endif; ?>
                <form class="send-email-form d-inline" action="<?php echo e(route('send-email',$AthleteProfile->id)); ?>" method="get">
                    <button class="btn btn-warning my-2">
                        Send Email
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="3" class="text-center py-5 error-box-table">
                No record found
            </td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<div id="paginationLinks">
    <?php echo e($AthleteProfiles->links()); ?>

</div><?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/athletes/getList.blade.php ENDPATH**/ ?>