
<?php $__env->startSection('title'); ?>
    Change Password
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="cont">
    
        <form class="form-l" id="subm" method="post" action="<?php echo e(route('updatePassword',auth()->user()->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card border-0 mb-4 shadow-sm">
                <div class="card-body p-lg-5">
                    <div class="mb-4">
                        <h4 class="mb-1">Change Password</h4>
                        
                    </div>
                    <form class="row gy-3 needs-validation" novalidate>
                        <div class="col-lg-7">
                            <label for="securityOldPasswordInput" class="form-label">Old Password</label>
                            <input type="password"  name="old_password"  class="form-control" id="securityOldPasswordInput"  />

                        </div>

                        <div class="col-lg-7">
                            <label for="securityNewPasswordInput" class="form-label">New Password</label>
                            <input type="password"  name="new_password"  class="form-control" id="securityNewPasswordInput"  />

                            <div class="form-text">Make sure it's at least 15 characters OR at least 8 characters including a number and a lowercase letter. Learn more.</div>
                        </div>

                        <div class="col-lg-7">
                            <label for="securityConfirmPasswordInput" class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password"  class="form-control" id="securityConfirmPasswordInput"  />

                            <div class="form-text">Make sure match with above new password</div>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-dark my-3 me-2" type="submit">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\charity-funders\resources\views/customer/passwordchange.blade.php ENDPATH**/ ?>