
<?php $__env->startSection('title'); ?>
    My Account
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="cont">
        

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-lg-5">
                <div class="mb-5">
                    <h4 class="mb-1">Account Information</h4>

                </div>
                <form class="row g-3 needs-validation" novalidate>
                    <div class="col-lg-12 col-md-12">
                        <label for="profileFirstNameInput" class="form-label">Name</label>
                        <input type="text" class="form-control" id="profileFirstNameInput" value="<?php echo e(auth()->user()->name); ?>" required />
                        <div class="invalid-feedback">Please enter name.</div>
                    </div>
                    <div class="col-lg-12 col-md-12">
                        <label for="profileLastNameInput" class="form-label">Email</label>
                        <input type="text" class="form-control" id="profileLastNameInput"  value="<?php echo e(auth()->user()->email); ?>" required />
                        <div class="invalid-feedback" >Please enter email.</div>
                    </div>









                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('customer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\charity-funders\resources\views/customer/profile.blade.php ENDPATH**/ ?>