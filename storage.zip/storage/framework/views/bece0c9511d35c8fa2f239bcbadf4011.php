<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-light navbar-shadow menu-border navbar-brand-center"
    role="navigation" data-menu="menu-wrapper">
    <!-- Horizontal menu content-->
    <div class="navbar-container main-menu-content center-layout" data-menu="menu-container">
        <!-- Navigation -->
        <ul class="navigation-main nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
            <!-- Dashboard -->
            <li class="nav-item <?php echo e(Route::is('dashboard') ? 'active' : ''); ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>"
                    data-toggle="dropdown"><i class="ft-home"></i>
                    <span data-i18n="Dashboard">Dashboard</span>
                </a>
            </li>

            <!-- Manage Company -->
            <li class="dropdown nav-item <?php echo e(Route::is('category*') || Route::is('funder*') ? 'active' : ''); ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link d-flex align-items-center" href="javascript:;"
                    data-toggle="dropdown"><i class="ft-box"></i>
                    <span data-i18n="Apps">Manage Funders</span>
                </a>
                <ul class="dropdown-menu">
                <li data-menu="">
                        <a class="dropdown-item d-flex align-items-center <?php echo e(Route::is('funder*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('funder.index')); ?>" data-toggle="dropdown">
                            <i class="ft-arrow-right submenu-icon"></i>
                            <span data-i18n="Email">Funders</span>
                        </a>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item d-flex align-items-center <?php echo e(Route::is('category.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('category.index')); ?>" data-toggle="dropdown">
                            <i class="ft-arrow-right submenu-icon"></i>
                            <span data-i18n="Email">Categories</span>
                        </a>
                    </li>
                    
                </ul>
            </li>

            <!-- Work Areas -->
            <li class="nav-item <?php echo e(Route::is('workareas.index') ? 'active' : ''); ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link d-flex align-items-center" href="<?php echo e(route('workareas.index')); ?>"
                    data-toggle="dropdown"><i class="ft-home"></i>
                    <span data-i18n="Dashboard">Work Areas</span>
                </a>
            </li>

            <!-- Types -->
            <li class="nav-item <?php echo e(Route::is('types.index') ? 'active' : ''); ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link d-flex align-items-center" href="<?php echo e(route('types.index')); ?>"
                    data-toggle="dropdown"><i class="ft-home"></i>
                    <span data-i18n="Dashboard">Types</span>
                </a>
            </li>

            <!-- Access Control -->
            <li class="dropdown nav-item <?php echo e(Request::is('roles*') || Request::is('users*') ? 'active' : ''); ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link d-flex align-items-center" href="javascript:;"
                    data-toggle="dropdown"><i class="ft-box"></i>
                    <span data-i18n="Apps">Access Control</span>
                </a>
                <ul class="dropdown-menu">
                    <li data-menu="">
                        <a class="dropdown-item d-flex align-items-center <?php echo e(Route::is('roles.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('roles.index')); ?>" data-toggle="dropdown">
                            <i class="ft-arrow-right submenu-icon"></i>
                            <span data-i18n="Email">Manage Roles & Permission</span>
                        </a>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item d-flex align-items-center <?php echo e(Route::is('users.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('users.index')); ?>" data-toggle="dropdown">
                            <i class="ft-arrow-right submenu-icon"></i>
                            <span data-i18n="Chat">Manage Users</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp82\htdocs\charity-funders\resources\views/management/layouts/navigation.blade.php ENDPATH**/ ?>