<form action="<?php echo e(route('types.store')); ?>" method="POST" id="ajaxSubmit" autocomplete="off">
  <?php echo csrf_field(); ?>
  <input type="hidden" id="listRefresh" value="<?php echo e(route('get.types')); ?>" />

<div class="row form-mar">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group ">
            <label>Name:</label>
            <input type="text" name="name" value="" placeholder="Name" class="form-control" />
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group ">
            <label>Address <small>(Optional)</small>:</label>
            <textarea name="description" row="2" class="form-control" placeholder="Description"></textarea>
        </div>
    </div>
   
</div>
<div class="row bottom-button-bar">
    <div class="col-12">
        <a type="button" class="btn btn-danger modal-sidebar-close position-relative top-1 closebutton">Close</a>
        <button type="submit" class="btn btn-primary submitbutton">Save</button>
    </div>
</div>
</form>


<?php /**PATH C:\xampp82\htdocs\charity-funders\resources\views/management/types/create.blade.php ENDPATH**/ ?>