<div class="row">
    <?php if(count($galleries) != 0): ?>
        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $thumbnail = $row->media->where('is_thumbnail', '1')->first();

                // Count media items for images and videos
                $imageCount = $row->media->where('file_type', 'image')->count();
                $videoCount = $row->media->where('file_type', 'video')->count();
            ?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="card box-card">
                    <div class="header py-2">
                        <div class="d-flex justify-content-between w-100 align-items-center">

                            <div class="creating-info d-flex">
                                <a href="javascript:;">
                                    <img class="creator-image p-2" src="<?php echo e(asset(optional($row->creator)->profile_image ?? 'users/fallback.jpg')); ?>" alt="Creator Image">
                                </a>
                                <div class="mx-2">
                                    <h2>
                                        <?php echo e($row->creator->name); ?>

                                    </h2>
                                    <small>
                                        <?php echo e(\Carbon\Carbon::parse($row->created_at)->format('Y-m-d')); ?>

                                    </small>
                                </div>
                            </div>

                            <ul class="header-dropdown mb-0">
                                <li class="dropdown">
                                    <a href="#" onclick="return false;" class="dropdown-toggle"
                                        data-bs-toggle="dropdown" role="button" aria-haspopup="true"
                                        aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery-edit')): ?>
                                            <li>
                                                <a href="<?php echo e(route('gallery.edit', $row->id)); ?>">Edit</a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery-delete')): ?>
                                            <li>
                                                <a href="javascript:;"
                                                    onclick="deletemodal('<?php echo e(route('gallery.destroy', $row->id)); ?>', `<?php echo e(route('get.gallery')); ?>`)">Delete</a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            </ul>
                        </div>

                    </div>
                    <div class="body p-0">
                        <div class="featured-img">
                            <img class="h-100" width="100%"
                                src="<?php echo e($thumbnail ? asset($thumbnail->file_path) : '/placeholder-image.jpg'); ?>"
                                alt="Thumbnail">
                        </div>
                    </div>
                    <div class="header info py-0">
                        <div class="row py-2 bg-white text-dark">
                            <div class="col-12 ">
                                <h5>
                                    <?php echo e($row->name); ?>

                                </h5>
                            </div>
                        </div>
                        <div class="row py-3">
                            <div class="col-6">
                                <label class="d-block m-0 font-weight-bold">Photos/Videos</label>
                                <?php echo e($row->getUniqueFileCount('image')); ?> Photos / <?php echo e($row->getUniqueFileCount('video')); ?>

                                Videos

                                
                                
                                

                                
                                
                                

                                
                                
                                
                            </div>

                            <div class="col-6">
                                <label class="d-block m-0 font-weight-bold">Event Name</label>
                                <?php echo e(optional($row->event)->name); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="8" class="text-center py-5 error-box-table">
                No record found
            </td>
        </tr>
    <?php endif; ?>
    <div class="col-12">
        <div id="paginationLinks">

        </div>
    </div>
</div>



<style>
    .header-dropdown {
        position: unset !important
    }
</style>














































































<div id="paginationLinks">
    <?php echo e($galleries->links()); ?>

</div>
<?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/gallery/getList.blade.php ENDPATH**/ ?>