
<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>

        .avatar-upload {
            position: relative;
            max-width: 205px;
            margin: 5px auto;
        }
        .avatar-upload .avatar-edit {
            position: absolute;
            right: 10%;
            z-index: 1;
            bottom: 10px;
        }
        .avatar-upload .avatar-edit input {
            display: none;
        }
        .avatar-upload .avatar-edit input + label {
            display: inline-flex;
            width: 40px;
            height: 40px;
            margin-bottom: 0;
            border-radius: 100%;
            background: #FFFFFF;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
            cursor: pointer;
            font-weight: normal;
            transition: all 0.2s ease-in-out;
            align-items: center !important;
            justify-content: center;
            background: #D95000;
            color: #fff;
            border: 3px solid white;
            padding: 0;
        }
        .avatar-upload .avatar-edit input + label:hover {
            background: #f1f1f1;
            border-color: #d6d6d6;
        }
        .avatar-upload .avatar-preview {
            width: 192px;
            height: 192px;
            position: relative;
            border-radius: 100%;
            border: 6px solid #F8F8F8;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
        }
        .avatar-upload .avatar-preview > div {
            width: 100%;
            height: 100%;
            border-radius: 100%;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

    </style>
    <!-- Center Main Content -->
    <section class="center-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <div class="tab-b">
                        <ul class="tab-product wow fadeInRight">
                            <li data-targetit="box-1" class="current">
                                <a href="#tab-1" data-toggle="tab"><span class="material-symbols-outlined">person</span> General</a>
                            </li>
                            <li data-targetit="box-2" >
                                <a href="#tab-2" data-toggle="tab"><span class="material-symbols-outlined">lock</span> Watermark</a>
                            </li>
                            
                            
                            
                            <li data-targetit="box-4" >
                                <a href="#tab-2" data-toggle="tab"><span class="material-symbols-outlined">history</span> Login History</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="tab-b">
                        <div class="box-1 showfirst tab-content card">
                            <div class="container p-5">
                                <?php echo $__env->make('management.theme.includes.error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form class="form-l" id="subm" method="post" action="<?php echo e(route('profile-settings',auth()->user()->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    

                                    <div class="row">
                                        <div class="col-md-6 mx-auto">
                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <input type='file' id="imageUpload" name="profile_image" accept=".png, .jpg, .jpeg" />
                                                    <label for="imageUpload">
                                                        <span class="material-symbols-outlined">edit</span>
                                                    </label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div id="imagePreview" style="background-image: url('<?php echo e(asset(auth()->user()->profile_image)); ?>');">
                                                    </div>
                                                </div>
                                            </div>
                                            <h1 class="text-center font-weight-bold my-4"><?php echo e(auth()->user()->name); ?></h1>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                        
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" value="<?php echo e(auth()->user()->name ?: ''); ?>" name="name" class="form-control" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="email" value="<?php echo e(auth()->user()->email ?: ''); ?>" name="email" class="form-control" placeholder="Email">
                                            </div>
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </div>
                                    <div class="row">

                                        <div class="col-md-12 text-right">
                                            <button type="submit" class="btn btn-primary">UPDATE</button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                        <div style="display: none" class="box-2 tab-content card">
                            <div class="container p-5">
                                <?php echo $__env->make('management.theme.includes.error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form class="form-l" id="subm" data-reset="true" method="post" action="<?php echo e(route('updatePassword',auth()->user()->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    

                                    <div class="row">
                                        <div class="col-md-8 mb-3">
                                            <h2>Edit your password</h2>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label>Old Password</label>
                                                <input type="text" name="old_password" class="form-control" placeholder="Old Password">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label>New Password</label>
                                                <input type="text" name="new_password" class="form-control" placeholder="New Password">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label>Confirmed New Password</label>
                                                <input type="text" name="confirm_password" class="form-control" placeholder="Confirmed New Password">
                                            </div>
                                        </div>
                                        <div class="col-md-12 text-">
                                            <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div style="display: none" class="box-3 tab-content">
                            <div class="prfoilesetting-header">
                                <img class="cover-ph" src="assets/images/cover.png">
                                <div class="but-abs">
                                    <a href="#" class="btn-uploadcover"><span class="material-symbols-outlined">photo_camera</span> Upload Cover</a>
                                </div>
                                <div class="profile-abs">
                                    <div class="pfp-set">
                                        <img src="assets/images/profile.png">
                                        <a href="#" class="edit-profile"><span class="material-symbols-outlined">edit</span></a>
                                    </div>
                                    <h1>Alexander Pierce</h1>
                                </div>
                            </div>
                            <div class="profile-form">







                                <form class="form-l">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3>Edit your Security</h3>
                                            <h5>Protect your account with 2-Step Verification</h5>
                                        </div>
                                        <div class="col-md-12 mb">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="a" checked> Authentication App
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="a" checked> Authentication Email
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Let’s Set up your Email</label>
                                                <h6>What email do you want to use?</h6>
                                                <input type="text" class="form-control" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="col-md-12 text-right">
                                            <a href="#" class="btn btn-primary">Save</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div style="display: none" class="box-4 tab-content ">
                            <div class="card">
                                <div class="body">
                                    <div class="profile-form">

                                        <?php
                                            use App\Models\User;
                                            use Carbon\Carbon;
                                            $users_data = User::loginHistory();
                                        ?>





                                        <form class="form-l">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h3>Recent activity</h3>
                                                </div>
                                                <div class="col-md-12">
                                                    <table style="font-size: 12px" class="table tab-des login-history">
                                                        <thead>
                                                        <tr>
                                                            <th>Access Type <span>(Browser, Mobile, etc)</span></th>
                                                            <th>Location</th>
                                                            <th>Date/Time <span>(Displayed in your time zone)</span></th>
                                                        </tr>

                                                        </thead>
                                                        <tbody>
                                                        <?php if(isset($users_data->loginHistories)): ?>
                                                            <?php $__currentLoopData = $users_data->loginHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><p><?php echo e($item->header); ?></p></td>
                                                                    <td><?php echo e($item->location); ?></td>
                                                                    <?php
                                                                        $createdAt = Carbon::parse($item->created_at);
                                                                        $currentTime = Carbon::now();

                                                                        // Calculate the difference in seconds, minutes, or hours
                                                                        $differenceInSeconds = $createdAt->diffInSeconds($currentTime);
                                                                        $differenceInMinutes = $createdAt->diffInMinutes($currentTime);
                                                                        $differenceInHours = $createdAt->diffInHours($currentTime);

                                                                        // Format the timestamp as "h:i A" (e.g., 1:59 PM)
                                                                        $formattedTime = $createdAt->format('h:i A');

                                                                        // Display the result based on the actual difference
                                                                        $timeDifference = '';
                                                                        if ($differenceInHours > 0) {
                                                                            $timeDifference = $differenceInHours . ' hour' . ($differenceInHours > 1 ? 's' : '');
                                                                        } elseif ($differenceInMinutes > 0) {
                                                                            $timeDifference = $differenceInMinutes . ' minute' . ($differenceInMinutes > 1 ? 's' : '');
                                                                        } else {
                                                                            $timeDifference = $differenceInSeconds . ' second' . ($differenceInSeconds > 1 ? 's' : '');
                                                                        }
                                                                    ?>

                                                                    <td><?php echo e($formattedTime); ?> (<?php echo e($timeDifference); ?> ago)</td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Center Main content End -->
<?php $__env->stopSection(); ?>




























<script>

    function previewImage(event) {
        var fileInput = event.target;
        var imagePreview = document.getElementById("account-upload-img");
        // Check if a file is selected
        if (fileInput.files.length > 0) {
            var file = fileInput.files[0];

            // Check if the selected file is an image
            if (file.type.startsWith("image/")) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    // Display the image preview
                    imagePreview.src = e.target.result;
                };

                reader.readAsDataURL(file);
            } else {
                imagePreview.src = "#"; // Clear the image preview
            }
        } else {
            // Clear the image preview if no file is selected
            imagePreview.src = "#";
        }
    }
</script>

<?php echo $__env->make('management/layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/studio/index.blade.php ENDPATH**/ ?>