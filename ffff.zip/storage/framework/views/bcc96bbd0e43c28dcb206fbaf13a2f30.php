<table class="table">
    <thead>
    <tr>
        <th class="col-lg-1">S no.</th>
        <th class="col-lg-3">Name</th>
        <th class="col-lg-3">email</th>
        <th >role</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php if(count($users) != 0): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($key+1); ?></td>
            <td>
                <a href="javascript:;" onclick="openModal('<?php echo e(route('users.edit',$user->id)); ?>','View User',true)">
                <?php echo e($user->name); ?>

                </a>
            </td>
            <td><?php echo e($user->email); ?></td>
            <td>
                <?php if(!empty($user->getRoleNames())): ?>
                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="badge badge-success"><?php echo e($v); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </td>
            <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                    <button class="btn btn-primary" onclick="openModal('<?php echo e(route('users.edit',$user->id)); ?>','Edit User')"><span class="material-symbols-outlined">edit</span></button>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                    <?php if($user->id != 1): ?>
                        <button class="btn btn-danger "  onclick="deletemodal('<?php echo e(route('users.destroy',$user->id)); ?>')"><span class="material-symbols-outlined">delete</span></button>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="10" class="text-center py-5 error-box-table">
                No record found
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<div id="paginationLinks">
    <?php echo e($users->links()); ?>

</div>
<?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/users/getList.blade.php ENDPATH**/ ?>