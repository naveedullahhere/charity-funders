<table class="table">
    <thead>
    <tr>
        <th class="col-lg-3">S no.</th>
        <th class="col-lg-3">Name</th>
        <th class="col-lg-3">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php if(count($roles) != 0): ?>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($key+1); ?></td>
                <td>
                    <a href="javascript:;" onclick="openModal('<?php echo e(route('roles.edit',$role->id)); ?>','View Role',true)">
                        <?php echo e($role->name); ?>

                    </a>
                </td>
                <td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                        <?php if(!in_array($role->id, [1,2])): ?>
                        <button class="btn btn-primary" onclick="openModal('<?php echo e(route('roles.edit',$role->id)); ?>','Edit Role')"><span class="material-symbols-outlined">edit</span></button>
                        <?php else: ?>
                            <button class="btn btn-primary" onclick="openModal('<?php echo e(route('roles.edit',$role->id)); ?>','Edit Role',true)"><span class="material-symbols-outlined">edit</span></button>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                        <?php if(!in_array($role->id, [1,2])): ?>
                            <button class="btn btn-danger "  onclick="deletemodal('<?php echo e(route('roles.destroy',$role->id)); ?>')"><span class="material-symbols-outlined">delete</span></button>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="10" class="text-center py-5 error-box-table">
                No record found
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<div id="paginationLinks">
    <?php echo e($roles->links()); ?>

</div>
<?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/roles/getList.blade.php ENDPATH**/ ?>