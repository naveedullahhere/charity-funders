<?php echo $__env->make('management.theme.includes.error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::open(array('route' => 'roles.store','method'=>'POST','id'=>'subm')); ?>

<input type="hidden" id="listRefresh" value="<?php echo e(route('get.roles')); ?>" />

<div class="row form-mar">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Name:</label>
            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label>Permission:</label>
            <br/>
            
            
            
            
            


            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value->parent_id === null): ?>
                    


                    <div class="permission-container">
                        <div class="custom-accordion row py-0">
                            <label class="col-11 py-2 text-capitalize"><?php echo e(Form::checkbox('permission[]', $value->name, false, array('class' => 'parent'))); ?>

                                <span><?php echo e($value->name); ?></span></label>
                            <?php if($permission->where('parent_id',$value->id)->count() != 0): ?>
                                <span class="material-symbols-outlined pl-3 col-1 text-right d-flex align-items-center border-left">expand_more</span>
                            <?php endif; ?>
                        </div>
                        <div class="sub-permissions" style="display: none">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($subPermission->parent_id == $value->id): ?>
                                    <label class="pl-5 py-2"><?php echo e(Form::checkbox('permission[]', $subPermission->name, false, array('class' => 'child'))); ?>

                                        <span><?php echo e($subPermission->name); ?></span></label>
                                    <br/>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div class="row text-center center">
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Save</button>
        <button type="button" class="btn btn-danger" data-close="model">Cancel</button>
    </div>
</div>
<?php echo Form::close(); ?>


<script>
    $(document).ready(function() {
        $('.parent').change(function() {
            $(this).parents('.permission-container').find('.sub-permissions').find('.child').prop('checked', $(this).prop('checked'));
        });
        $('.child').change(function() {
            var parentCheckbox = $(this).closest('.permission-container').find('.parent');
            parentCheckbox.prop('checked', $(this).closest('.sub-permissions').find('.child:checked').length > 0);
        });
    });
    $('.custom-accordion > span').on('click',function(){
        $(this).parents('.custom-accordion').siblings('.sub-permissions').toggle('slow');
    })
</script>
<?php /**PATH C:\xampp82\htdocs\AJP-studio\resources\views/management/roles/create.blade.php ENDPATH**/ ?>