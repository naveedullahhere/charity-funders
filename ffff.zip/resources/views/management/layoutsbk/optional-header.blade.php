<div class="row">
    <div class="col-md-12 mb">
        <a href="{{url('dashboard')}}" class="btn-theme-nobackground">Overview</a>
        <a href="{{route('leads-kanban-view')}}" class="btn-theme-nobackground">Leads</a>
        <a href="#" class="btn-theme-nobackground">User Wise</a>
    </div>
</div>
