@include('management/layouts/sidebar')
@include('management/layouts/header')
@include('management/layouts/footer')
@include('management.theme.includes.modals')
