@include('frontend/layouts/header')

<section class="content">

    @yield('content')
</section>
@include('frontend/layouts/footer')
